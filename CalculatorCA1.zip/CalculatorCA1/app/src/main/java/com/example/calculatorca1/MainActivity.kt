package com.example.calculatorca1

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etSub1: EditText = findViewById(R.id.etSub1)
        val etSub2: EditText = findViewById(R.id.etSub2)
        val etSub3: EditText = findViewById(R.id.etSub3)
        val btnCalculate: Button = findViewById(R.id.btnCalculate)
        val tvResult: TextView = findViewById(R.id.tvResult)

        btnCalculate.setOnClickListener {
            val s1 = etSub1.text.toString()
            val s2 = etSub2.text.toString()
            val s3 = etSub3.text.toString()

            if (s1.isEmpty() || s2.isEmpty() || s3.isEmpty()) {
                tvResult.text = "Enter all values!"
                return@setOnClickListener
            }

            val sub1 = s1.toInt()
            val sub2 = s2.toInt()
            val sub3 = s3.toInt()
            val total = sub1 + sub2 + sub3
            val total_avg = total / 3.0
            val cgpa=total_avg/10.0
            tvResult.text = "CGPA: %.2f".format(cgpa)
        }
    }
}